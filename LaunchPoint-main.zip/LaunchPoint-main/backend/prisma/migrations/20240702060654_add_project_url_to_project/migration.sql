-- AlterTable
ALTER TABLE "Project" ADD COLUMN     "project_url" TEXT;
