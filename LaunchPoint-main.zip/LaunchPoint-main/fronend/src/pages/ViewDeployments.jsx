import React from 'react'

function ViewDeployments() {
  return (
    <div>ViewDeployments</div>
  )
}

export default ViewDeployments